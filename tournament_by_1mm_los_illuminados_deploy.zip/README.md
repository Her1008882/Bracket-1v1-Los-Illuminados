# Tournament BY 1 MM — Los Illuminados

Website bracket editable, siap untuk GitHub Pages atau Vercel.

## GitHub Pages
Upload seluruh isi folder ini ke repository GitHub, lalu aktifkan:
Settings → Pages → Deploy from branch → main → /(root)

## Vercel
Import repository ini ke Vercel dan deploy sebagai static site.

Tidak membutuhkan build command atau framework.

## Catatan
- `index.html` = website utama
- `logo.jpg` = logo yang diberikan
- Sound dibuat dengan Web Audio API sehingga tidak membutuhkan file audio eksternal.
